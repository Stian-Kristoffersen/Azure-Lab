# Install applications

# Install Sysmon
choco install -y sysmon

# Install Notepad++
choco install -y notepadplusplus.install